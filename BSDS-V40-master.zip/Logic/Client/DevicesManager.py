class Device:
    def __init__(self):
        pass

    major = 0
    minor = 0
    build = 0