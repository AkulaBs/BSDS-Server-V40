from Logic.Helpers.GlobalID import GlobalID


class LogicDataTables:
    def getDataById(self, globalId):
        GlobalID.getClassID(globalId)